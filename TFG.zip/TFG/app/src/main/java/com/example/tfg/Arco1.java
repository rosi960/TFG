package com.example.tfg;
import android.media.MediaPlayer;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ImageView;
import android.widget.Button;

import androidx.appcompat.app.AppCompatDelegate;

import com.example.tfg.model.Dialogo;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;


public class Arco1 {
    private final MainActivity mainActivity;

    private MediaPlayer mediaPlayer;

    private int counter;

    /* TODO: Hacer que las funcionalidades propias de un arco/escena sean genéricos:
    mostrar diálogo, mostrar botones para decisiones, cambios de escena...
     */
    public Arco1(MainActivity mainActivity) {
        this.mainActivity = mainActivity;
        this.counter = 0;
    }

    public void iniciar() throws IOException {
        mediaPlayer = MediaPlayer.create(mainActivity, R.raw.musica1);
        // Archivo "arco1"
        ArrayList<Dialogo> conversacionArco1 = cargarConversacionDesdeArchivo("arco1.csv");
        // Archivo "badEnding"
        ArrayList<Dialogo> conversacionBadEnding = cargarConversacionDesdeArchivo("badEnding.csv");
        // Pasamos la lista de diálogos al método de mostrar conversación
        mostrarConversacion(conversacionArco1, conversacionBadEnding);
        reproducirSonido();
    }
    private ArrayList<Dialogo> cargarConversacionDesdeArchivo(String nombreArchivo) throws IOException {
        try (InputStream is = mainActivity.getApplicationContext().getAssets().open(nombreArchivo)) {
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            CSVReader csvReader = new CSVReader(reader);
            // Array de líneas del fichero y lista que almacenará los diálogos
            String[] line;
            ArrayList<Dialogo> conversacion = new ArrayList<>();
            // Por cada línea del fichero creamos un elemento de diálogo para añadirlo a la conversación
            while ((line = csvReader.readNext()) != null) {
                // Cada elemento corresponde a personaje, reacción, fondo y línea.
                Dialogo d = new Dialogo(line[0], line[1], line[2], line[3]);
                conversacion.add(d);
            }
            return conversacion;
        } catch (CsvValidationException e) {
            // TODO: Controlar mejor la excepción
            throw new RuntimeException(e);
        }
    }
   /* public void iniciar() throws IOException {

        mediaPlayer = MediaPlayer.create(mainActivity, R.raw.musica1);
        // Accedemos al asset "arco1" que almacena el guión de la escena
        try (InputStream is = mainActivity.getApplicationContext().getAssets()
                .open("arco1.csv")) {

            // Inicializamos los readers para la lectura del contenido
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            // Dado que el fichero del arco está en formato CSV, usamos esta librería externa.
            // Se podría hacer parcialmente con readers nativos, pero esto simplifica la gestión.
            // NOTA: Añadida como dependencia a build.gradle para tenerla accesible y usable.
            CSVReader csvReader = new CSVReader(reader);

            // Array de líneas del fichero y lista que almacenará los diálogos
            String[] line;
            ArrayList<Dialogo> conversacion = new ArrayList<>();

            // Por cada línea del fichero creamos un elemento de diálogo para añadirlo a la conversación
            while ((line = csvReader.readNext()) != null) {
                // Cada elemento corresponde a personaje, reacción, fondo y línea.
                Dialogo d = new Dialogo(line[0], line[1], line[2], line[3]);
                conversacion.add(d);
            }
            // Pasamos la lista de diálogos al método de mostrar conversación
            // Inicializar el MediaPlayer

            mostrarConversacion(conversacion);
             reproducirSonido();

        } catch (CsvValidationException e) { // TODO: Controlar mejor la excepción
            throw new RuntimeException(e);
        }
    }*/

    public void mostrarConversacion(ArrayList<Dialogo> conversacion, ArrayList<Dialogo> badEnding) {
        TextView textViewGameInfo = mainActivity.findViewById(R.id.textViewGameInfo);
        Button conversationalButton1 = mainActivity.findViewById(R.id.myConversacionalButton1);
        Button conversationalButton2 = mainActivity.findViewById(R.id.myConversacionalButton2);
        Button conversationalButton3 = mainActivity.findViewById(R.id.myConversacionalButton3);
        Button conversationalButton4 = mainActivity.findViewById(R.id.myConversacionalButton4);
        // Establecer el límite de líneas inicial
        textViewGameInfo.setMaxLines(2);
        // Configurar el desplazamiento vertical en el TextView
        textViewGameInfo.setMovementMethod(new ScrollingMovementMethod());
        // Configurar el texto inicial con la primera línea
        mostrarDialogo(textViewGameInfo, conversacion.get(0));
        // Agregar clic para mostrar más líneas
        textViewGameInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Llevar la cuenta de los clicks que llevamos para avanzar en la lista de mensajes
                counter = counter + 1;
                // Añadimos un listener a los botones y en base al contador mostramos una cosa u otra
                conversationalButton1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (counter == 2)
                            mostrarDialogo(textViewGameInfo,  badEnding.get(0) );
                    }
                });
                //Toast.makeText(mainActivity.getApplicationContext(), "Hiciste click", Toast.LENGTH_SHORT).show();
                // Mostrar el siguiente texto en el TextView mientras haya contenido en la conversación
                if(counter < conversacion.size()) {
                    mostrarDialogo(textViewGameInfo, conversacion.get(counter));
                    if (counter == 2){
                        conversationalButton1.setText("Me tropiezo y me caigo por la borda");
                    }
                    if (counter == 33) {
                        conversationalButton1.setText("Pues no quiero entrar");
                    }
                }
            }
        });
    }
    public void mostrarDialogo(TextView textViewGameInfo, Dialogo dialogo){

        // Configura el texto a partir de la línea de diálogo
        textViewGameInfo.setText(dialogo.getLinea());
        // Sólo en caso de que se nos informe el fondo lo cambiamos (provisional)
        // TODO: Debería calcularse en cada línea de diálogo como el personaje/reacción
        if(dialogo.getFondo() != null){
            cambiarFondo(dialogo.getFondo());
        }

        // Si no hay personaje definido en el diálogo, solo aparece el texto
        if(dialogo.getPersonaje() == null || dialogo.getPersonaje().isEmpty()){
            hacerPersonajeInvisible();
        } else { // En caso afirmativo, muestra personaje y reacción alternativa
            hacerPersonajeVisible(dialogo.getPersonaje(), dialogo.getReaccion());
        }

    }

    private void cambiarFondo(String fondo){
        // Obtén la referencia a la ImageView del fondo
        ImageView imageViewBackground = mainActivity.findViewById(R.id.imageViewBackground);

        System.out.println("FONDO: " + fondo);

        // Obtén el ID del recurso dibujable que necesitas mostrar a partir del nombre
        int resID = mainActivity.getResources().getIdentifier
                (fondo, "drawable", mainActivity.getPackageName());

        System.out.println("RESID: " + resID);

        // Reestablece el recurso a partir del ID calculado.
        imageViewBackground.setImageResource(resID);
    }

    private void hacerPersonajeInvisible() {
        // Obtén la referencia a la ImageView del personaje
        ImageView characterImageView = mainActivity.findViewById(R.id.characterImageView);

        // Oculta la ImageView para que desaparezca
        characterImageView.setVisibility(View.INVISIBLE);
    }
    private void hacerPersonajeVisible(String personaje, String reaccion) {
        // Obtén la referencia a la ImageView del personaje
        ImageView characterImageView = mainActivity.findViewById(R.id.characterImageView);

        String imageName = "";
        // Si no hay reacción definida, obtén el recurso con el nombre del personaje
        if(reaccion == null || reaccion.isEmpty()){
            imageName = personaje;
        } else {
            // Si hay reacción, obtén el recurso como concatenación de los dos parámetros
            imageName = personaje.concat("_").concat(reaccion);
        }

        System.out.println("IMAGENAME: " + imageName);

        // Obtén el ID del recurso dibujable que necesitas mostrar a partir del nombre
        int resID = mainActivity.getResources().getIdentifier
                (imageName, "drawable", mainActivity.getPackageName());

        System.out.println("RESID: " + resID);

        // Reestablece el recurso a partir del ID calculado.
        characterImageView.setImageResource(resID);

        // Muestra la ImageView para que aparezca
        characterImageView.setVisibility(View.VISIBLE);
    }

    private void reproducirSonido() {
        if (mediaPlayer != null) {
            mediaPlayer.start();
        }
    }

}